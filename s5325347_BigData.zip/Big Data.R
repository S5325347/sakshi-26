library(httr)
library(jsonlite)

# Your Client ID and Client Secret
client_id <- "79bf92b6c08d4f12820b41e9d453b64b"
client_secret <- "cee97ba70fcb4a64b20e23eb6d3e4b5d"

# Prepare the request for the access token
response <- POST("https://accounts.spotify.com/api/token",
                 authenticate(client_id, client_secret),
                 body = list(grant_type = "client_credentials"),
                 encode = "form")

# Extract the access token
token_data <- content(response, type = "application/json")
access_token <- token_data$access_token



# Artist search query
artist_name <- "Adele"

# Use the access token to authenticate a request to search for the artist
search_response <- GET(url = paste0("https://api.spotify.com/v1/search?q=", URLencode(artist_name), "&type=artist"),
                       add_headers(Authorization = paste("Bearer", access_token)))

# Parse the response to find the artist ID
search_data <- content(search_response, type = "application/json")
artist_id <- search_data$artists$items[[1]]$id

# Print the artist ID
print(artist_id)





library(httr)
library(jsonlite)

# Replace 'artist_id' and 'your_access_token' with actual values
artist_id <- "4dpARuHxo51G3z768sgnrY"
access_token <- "BQB2kYte9kqIo99AgaOcxuftBEBp2nZ0hpJOwOKxRwN7TLEhCpVfCh4Wq2wsAUX0jBTHPrgypDeven-kxBVSjYJAE3Tq2TRDw6frbMKVG07uF-QqPAo"

response <- GET(paste0("https://api.spotify.com/v1/artists/", artist_id),
                add_headers(Authorization = paste("Bearer", access_token)))
data <- content(response, type = "application/json", as = "parsed")

# Check status code and data
if (status_code(response) == 200) {
    print(data$followers$total)
} else {
    print(paste("Error:", status_code(response)))
    print(data$error$message)  # This will print the error message from Spotify
}



library(igraph)

# Example data for 'edges'. Replace with your actual data.
edges <- data.frame(
  from = c("Adele", "Dua Lipa", "Ariana Grande", "Billie Eilish", "Adele"),
  to = c("Dua Lipa", "Ariana Grande", "Billie Eilish", "Adele", "Ariana Grande")
)

# Now create the graph
graph <- graph_from_data_frame(d = edges, directed = TRUE)
page_rank <- page_rank(graph)$vector
top_actors <- sort(page_rank, decreasing = TRUE)[1:5]

# Print top actors based on PageRank
print(top_actors)



unique_actors <- length(unique(c(edges$from, edges$to)))
print(unique_actors)





# Fetch artist's albums
albums_response <- GET(paste0("https://api.spotify.com/v1/artists/", artist_id, "/albums"),
                       add_headers(Authorization = paste("Bearer", access_token)))
albums_data <- content(albums_response, type = "application/json")

# List all albums and their IDs
if (status_code(albums_response) == 200) {
    album_names <- sapply(albums_data$items, function(x) x$name)
    album_ids <- sapply(albums_data$items, function(x) x$id)
    print(album_names)
} else {
    print(paste("Error fetching albums:", albums_data$error$message))
}




# Fetch tracks for the first album
tracks_response <- GET(paste0("https://api.spotify.com/v1/albums/", album_ids[1], "/tracks"),
                       add_headers(Authorization = paste("Bearer", access_token)))
tracks_data <- content(tracks_response, type = "application/json")

# List track names and their IDs
if (status_code(tracks_response) == 200) {
    track_names <- sapply(tracks_data$items, function(x) x$name)
    track_ids <- sapply(tracks_data$items, function(x) x$id)
    print(track_names)
} else {
    print(paste("Error fetching tracks:", tracks_data$error$message))
}



# Fetch audio features for the first track (as an example)
audio_features_response <- GET(paste0("https://api.spotify.com/v1/audio-features/", track_ids[1]),
                               add_headers(Authorization = paste("Bearer", access_token)))
audio_features_data <- content(audio_features_response, type = "application/json")

# Print audio features
if (status_code(audio_features_response) == 200) {
    print(audio_features_data)
} else {
    print(paste("Error fetching audio features:", audio_features_data$error$message))
}





library(tm)
library(SnowballC)

# Let's assume 'album_names' is already filled from your previous API calls
docs <- album_names

# Creating a corpus from the vector of album names
corpus <- Corpus(VectorSource(docs))

# Text Pre-processing
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords, stopwords("english"))
corpus <- tm_map(corpus, stemDocument)

# Creating Term-Document Matrix
tdm <- TermDocumentMatrix(corpus)

# Finding the terms with the highest frequency
top_terms <- findFreqTerms(tdm, 10)
print(top_terms)



print(docs)



library(tm)
library(SnowballC)

# Assuming 'album_names' is already filled from your previous API calls
docs <- album_names

# Creating a corpus from the vector of album names
corpus <- Corpus(VectorSource(docs))
print("Original Corpus:")
print(corpus)

# Convert to lowercase
corpus <- tm_map(corpus, content_transformer(tolower))
print("Lowercase Corpus:")
print(corpus)

# Remove punctuation
corpus <- tm_map(corpus, removePunctuation)
print("No Punctuation Corpus:")
print(corpus)

# Remove numbers
corpus <- tm_map(corpus, removeNumbers)
print("No Numbers Corpus:")
print(corpus)

# Remove common stopwords
corpus <- tm_map(corpus, removeWords, stopwords("english"))
print("No Stopwords Corpus:")
print(corpus)

# Stemming
corpus <- tm_map(corpus, stemDocument)
print("Stemmed Corpus:")
print(corpus)

# Creating Term-Document Matrix
tdm <- TermDocumentMatrix(corpus)

# Print TDM to see what it looks like
print(as.matrix(tdm))

# Finding the terms with the highest frequency
top_terms <- findFreqTerms(tdm, 10)
print("Top Terms:")
print(top_terms)



# Calculate centrality measures
deg <- degree(graph, mode="all")
betw <- betweenness(graph, directed=FALSE)
clos <- closeness(graph, mode="all")

# Print centrality scores for your artist
artist_node <- "Adele"  # assuming 'Adele' is a node in your graph
print(deg[artist_node])
print(betw[artist_node])
print(clos[artist_node])



# Girvan-Newman approach
gn_comm <- edge.betweenness.community(graph)
print(membership(gn_comm))

# Louvain method
infomap_comm <- cluster_infomap(graph)
print(membership(infomap_comm))


library(syuzhet)

# Assume 'track_names' contains textual data like lyrics or descriptions
sentiments <- get_sentiment(track_names, method="nrc")  # using NRC sentiment lexicon
print(mean(sentiments))



library(topicmodels)

# Assume you have a document-term matrix 'dtm'
lda <- LDA(tdm, k = 3)  # 'k' is the number of topics
topics <- terms(lda, 6)  # Get terms for each topic
print(topics)






library(rpart)
library(caret)


library(httr)
conflicts(detail = TRUE)

methods(content)

library(jsonlite)

features_list <- lapply(track_ids, function(track_id) {
    response <- GET(paste0("https://api.spotify.com/v1/audio-features/", track_id),
                    add_headers(Authorization = paste("Bearer", access_token)))
    if (status_code(response) == 200) {
        # Get content as raw text and manually parse JSON
        text_content <- rawToChar(response$content)
        json_content <- fromJSON(text_content)
        return(json_content)
    } else {
        print(paste("Failed to fetch for track ID:", track_id, "Status Code:", status_code(response)))
        return(NULL)
    }
})




# Convert the list to a dataframe
songs_features <- do.call(rbind, lapply(features_list, function(x) as.data.frame(t(x))))

# Assuming the first half are Adele's songs
songs_features$is_adele <- c(rep(1, length(track_ids)/2), rep(0, length(track_ids)/2))


set.seed(123)  # for reproducibility
trainIndex <- createDataPartition(songs_features$is_adele, p = 0.7, list = FALSE)
train_data <- songs_features[trainIndex,]
test_data <- songs_features[-trainIndex,]



# Check the structure of the train_data to identify list columns
str(train_data)

# Convert list columns to vectors
train_data[] <- lapply(train_data, function(x) if(is.list(x)) unlist(x) else x)
test_data[] <- lapply(test_data, function(x) if(is.list(x)) unlist(x) else x)

# Verify the structure after conversion
str(train_data)

# Rebuild the decision tree model
tree_model <- rpart(is_adele ~ ., data = train_data, method = "class")

# Additional libraries
library(ggplot2)
library(caret)
library(pROC)

# Data Visualization
feature_plot <- ggplot(train_data, aes(x=tempo, y=energy, color=factor(is_adele))) +
  geom_point(alpha=0.5) +
  theme_minimal() +
  labs(title="Tempo vs Energy by Artist", x="Tempo", y="Energy")
print(feature_plot)

# List of non-predictive features
non_predictive_features <- c("uri", "track_href", "analysis_url")

# Remove non-predictive features from both training and testing datasets
train_data <- train_data[, !(names(train_data) %in% non_predictive_features)]
test_data <- test_data[, !(names(test_data) %in% non_predictive_features)]

# Rebuild the decision tree model without the non-predictive features
tree_model <- rpart(is_adele ~ ., data = train_data, method = "class")


# Example Code (Assuming you have historical follower data)
followers_data <- data.frame(date = c("2021-01", "2022-01", "2023-01"),
                             followers = c(10000, 15000, 20000))
ggplot(followers_data, aes(x = date, y = followers)) +
  geom_line() +
  labs(title = "Artist Popularity Over Time", x = "Date", y = "Followers")


# Example Code (Using your existing 'graph' object)
plot(graph, vertex.size = page_rank(graph)$vector * 100,
     vertex.label.cex = 0.7,
     main = "Artist Network Analysis")


# Example Code (Assuming you have the release dates)
album_release_data <- data.frame(year = c("2018", "2019", "2021"),
                                 album_count = c(1, 2, 1))
ggplot(album_release_data, aes(x = year, y = album_count)) +
  geom_bar(stat = "identity") +
  labs(title = "Album Release Frequency", x = "Year", y = "Number of Albums")



# Assuming 'sentiments' vector from your code
sentiment_data <- data.frame(sentiment = sentiments)
ggplot(sentiment_data, aes(x = sentiment)) +
  geom_histogram(bins = 10, fill = "blue") +
  labs(title = "Sentiment Distribution in Track Names", x = "Sentiment", y = "Frequency")


# Assuming 'top_terms' and 'tdm' from your code
term_data <- rowSums(as.matrix(tdm))
term_data <- sort(term_data, decreasing = TRUE)
bar_data <- data.frame(term = names(term_data)[1:10], freq = term_data[1:10])
ggplot(bar_data, aes(x = reorder(term, freq), y = freq)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Top Terms in Album Titles", x = "Terms", y = "Frequency")
